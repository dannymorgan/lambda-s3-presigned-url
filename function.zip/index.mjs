import AWS from 'aws-sdk';

const s3 = new AWS.S3();
const bucketName = process.env.BUCKET_NAME;

export const handler = async (event) => {
    try {
        if (!event.queryStringParameters || !event.queryStringParameters.object_name) {
            throw new Error("Missing required query parameter 'object_name'");
        }

        const objectName = event.queryStringParameters.object_name;

        const params = {
            Bucket: bucketName,
            Key: objectName,
            Expires: 3600  // URL expiration time in seconds
        };

        const uploadURL = await s3.getSignedUrlPromise('putObject', params);
        return {
            statusCode: 200,
            body: JSON.stringify({ upload_url: uploadURL })
        };
    } catch (error) {
        return {
            statusCode: 400,
            body: JSON.stringify({ error: error.message })
        };
    }
};
